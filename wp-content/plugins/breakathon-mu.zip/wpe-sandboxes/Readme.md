## WP Engine Training Sandbox Plugin

### The purpose of this plugin is to break WordPress.

This is for training porpoises.

When active, it adds a button to the admin menu with links to break stuff.

When clicked, a Break link will run the break using admin-ajax, log the user out, and show a pop-up with the issue's description.

There will probably be more here later, but I wanted to make a Readme, so I made a Readme.
You can stop reading now.
