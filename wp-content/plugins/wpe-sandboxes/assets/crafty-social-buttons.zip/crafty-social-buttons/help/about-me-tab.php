<p><strong>About Me</strong></p>

<p>Made with love by <a href="http://sarahhenderson.info">Sarah Henderson</a>, a freelance web developer from New Zealand.</p>
<p>I recently learned to crochet and thought of starting up a crochet related blog to show off my new creations.  I got a bit sidetracked making pretty icons and WordPress plugins and thought that others in the crafty community might want to use them too.</p>
<p>I have also created a WordPress plugin that creates a 'Pattern' post type with all the sections you normally find in a pattern.  I hope to make that available also soon.</p>

<p>For more information about this plugin, please visit 
<a href="http://sarahhenderson.github.io/Crafty-Social-Buttons">the plugin's website.</a>

<p>I really hope you find this plugin useful. Please don't hesitate to <a href="mailto:sarah@sarahhenderson.info">contact me</a> with any issues you have, or any requests for new features.  If you want to contribute towards it's further development, (or you just want to say thank you), you can <a href="http://sarahhenderson.info/buy-me-a-coffee">buy me a coffee</a>. 	
