<?php
/**
 * Plugin Name: Ye Olde Customme Loginne
 * Description: Do special custom login things
 * Version: 0.1
 * Author: Daniel Bennett
 * Text Domain: db-customme-loginne
 *
 * @package Customme Loginne
 * @author Daniel Bennett
 */

function add_redirect_thing(){
    echo '<script>document.location = "http://someolddomain.com/login.aspx";</script>';
}
add_action('login_head', 'add_redirect_thing');
