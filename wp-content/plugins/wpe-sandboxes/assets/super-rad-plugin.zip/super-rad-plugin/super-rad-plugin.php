<?php
/*
Plugin Name: Super Rad Plugin
Plugin URI: http://wpengine.com/
Description: This plugin loads a lot of scripts for reasons!
Version: 1
Author: Daniel Bennett
Author URI: http://wpengine.com
License: GPL3
*/

// Register main function
function rw_manyscripts() {

//	wp_enqueue_script('','',false);
	for($i=1; $i <= 10; $i++){
		wp_enqueue_script("thisaintathing$i","http://totallyrealdomain$i.com/blerg$i.js",false);
	}
}
add_action('wp_enqueue_scripts', 'rw_manyscripts');
