<?php 
/*
Plugin Name: Test Plugin
*/

function runQuery(){
    global $wpdb;

    $results = $wpdb->get_results('SELECT SLEEP(120)');

}

add_action( 'publish_post', 'runQuery');


?>
